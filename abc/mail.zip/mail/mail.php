<?php
print_r($_POST);
mail($_POST['to'],$_POST['subject'],$_POST['message']);

?>