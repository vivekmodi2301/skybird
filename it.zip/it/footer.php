</div>
        <div class="box"><div class="border-top"><div class="border-right"><div class="border-bot"><div class="border-left"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- footer -->
  <div id="footer">
    <div class="indent">
      <div class="fleft">Copyrights - Axixa Technology</div>
      <div class="fright"><!-- VLinks -->
</div>
    </div>
  </div>
</div>