<div class="title"><img src="images/5page-title.gif" alt="" /></div>
          <p class="p1">You are supposed to place some contact infromation on this page. You may place a map here with some instructions on how to get to your office or just a contact form. Note that the contact form below is not working.</p>
          <form id="contacts-form" action="" method="post">
            <fieldset>
              <div class="field">
                <label>Your Name:</label>
                <input type="text" value=""/>
              </div>
              <div class="field">
                <label>Your E-mail:</label>
                <input type="text" value=""/>
              </div>
              <div class="field">
                <label>Your Website:</label>
                <input type="text" value=""/>
              </div>
              <div class="field">
                <label>Your Message:</label>
                <textarea cols="1" rows="1"></textarea>
              </div>
              <div class="wrapper"><a href="#" onclick="document.getElementById('contacts-form').submit()" class="link"><em><b>Send Your Message</b></em></a></div>
            </fieldset>
          </form>
        </div>
