<?php 
session_destroy();
 ?>
 <script>
 	location.href="index.php?mod=login&do=login";
 </script>