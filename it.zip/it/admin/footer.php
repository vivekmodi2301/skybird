<div style="
						
                     background-color:#A1D1FF ; 
                     height:200px;
                     width:100%; margin-top:100px; color:#FFFFFF;  font-size: 32px;  font-weight: bold;  padding-top: 35px; text-align:center;  "> work in progress</div>
</div>
    </body>
</html>